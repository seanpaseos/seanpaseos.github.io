document.getElementById('changeTextBtn').addEventListener('click', function() {
    document.getElementById('paragraph').textContent = "You clicked the button!";
});
